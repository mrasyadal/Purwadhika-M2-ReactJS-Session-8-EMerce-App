import React from "react";

class Cart extends React.Component {
	render() {
		return (
			<div>
				<h1>Cart Page</h1>
			</div>
		);
	}
}

export default Cart;
