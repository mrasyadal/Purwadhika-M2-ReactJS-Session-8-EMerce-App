import React from "react";

class History extends React.Component {
	render() {
		return (
			<div>
				<h1>History Page</h1>
			</div>
		);
	}
}

export default History;
