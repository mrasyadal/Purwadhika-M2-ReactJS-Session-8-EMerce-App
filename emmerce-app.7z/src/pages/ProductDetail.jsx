import React from "react";

class ProductDetail extends React.Component {
	render() {
		return (
			<div>
				<h1>Product Detail Page</h1>
			</div>
		);
	}
}

export default ProductDetail;
