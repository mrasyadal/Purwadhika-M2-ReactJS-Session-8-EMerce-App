import React from "react";

class Admin extends React.Component {
	render() {
		return (
			<div>
				<h1>Admin Page</h1>
			</div>
		);
	}
}

export default Admin;
