import Axios from "axios";
import { API_URL } from "../../constants/API";

export const registerUser = ({ fullName, username, email, password }) => {
	// parameter yang masuk ke registerUser (berupa object) akan langsung di-destructure apabila parameternya dibuat dengan syntax di atas
	// parameter (object) yang masuk harus memiliki 4 field di atas
	return (dispatch) => {
		Axios.post(`${API_URL}/users`, {
			fullName,
			username,
			email,
			password,
			role: "user",
		})
			.then((postData) => {
				// `postData` adalah data yg berhasil dimasukkan ke json-server. Data ini tidak sama dengan data yg dikirim oleh Axios (ada tambahan key/field `id`)
				// dalam App ini, data di `postData` adalah: fullName, username, email, password, role, id
				delete postData.data.password;
				// delete password sebelum data input di-dispatch

				dispatch({
					type: "USER_LOGIN",
					payload: postData.data,
				});
				alert(`Berhasil mendaftarkan user`);
			})
			.catch(() => {
				alert(`Gagal mendaftarkan user`);
			});
	};
};
