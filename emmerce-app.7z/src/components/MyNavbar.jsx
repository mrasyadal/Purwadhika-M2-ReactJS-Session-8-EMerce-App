import React from "react";
import {
	Navbar,
	Nav,
	NavItem,
	NavLink,
	UncontrolledDropdown,
	DropdownToggle,
	NavbarBrand,
	NavbarText,
	DropdownMenu,
	DropdownItem,
} from "reactstrap";
import { Link } from "react-router-dom";
import { connect } from "react-redux";

class MyNavbar extends React.Component {
	render() {
		return (
			<div>
				<Navbar color="light" light>
					{/* `color` dan `light` adalah props */}
					<NavbarBrand>Emmerce</NavbarBrand>
					<Nav>
						<NavItem>
							<NavbarText>Hello, {this.props.userGlobal.username}!</NavbarText>
						</NavItem>
						<UncontrolledDropdown nav inNavbar>
							{/* `nav` dan `inNavbar` adalah props. `inNavbar` menandakan tag ini ada di dalam nav */}
							<DropdownToggle nav caret>
								{/* `caret` memberikan panah kecil ke bawah di samping tulisan `Pages` */}
								Pages
							</DropdownToggle>
							<DropdownMenu right>
								<DropdownItem>
									<Link to="/cart">Cart</Link>
								</DropdownItem>
								<DropdownItem>
									<Link to="/admin">Admin</Link>
								</DropdownItem>
								<DropdownItem>
									<Link to="/history">History</Link>
								</DropdownItem>
								<DropdownItem>
									<Link to="/register">Register</Link>
								</DropdownItem>
							</DropdownMenu>
						</UncontrolledDropdown>
					</Nav>
				</Navbar>
			</div>
		);
	}
}

const mapStateToProps = (state) => {
	return {
		userGlobal: state.user,
		// ga pakai `this.state` karena `state` tidak berasal dari page ini, melainkan dari page Register.jsx
		// pakai `.user` di `state.user` karena di /reducers/index.js yang diexport adalah combineReducers dengan field/property/key bernama `user`
	};
};

export default connect(mapStateToProps)(MyNavbar);
